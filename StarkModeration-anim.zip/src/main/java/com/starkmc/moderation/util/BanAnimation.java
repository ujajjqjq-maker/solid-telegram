package com.starkmc.moderation.util;

import com.starkmc.moderation.ModerationPlugin;
import com.destroystokyo.paper.profile.ProfileProperty;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.time.Duration;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.object.ObjectContents;
import net.kyori.adventure.text.object.PlayerHeadObjectContents;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.SoundCategory;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.TextDisplay;
import org.bukkit.Color;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * أنيميشن الباند: صوت معبد البحر + راس الإداري (أو Herobrine للكونسل) يكبر قدام وجه اللاعب،
 * بعدها اسم الإداري في النص بالأحمر + "Watching you, watch yourself" ثم يتبند.
 * الراس ما يشوفه غير اللاعب المبند (ItemDisplay مخفي عن الباقي).
 */
public final class BanAnimation {
   private static final MiniMessage MM = MiniMessage.miniMessage();
   private static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();
   private static final Set<Display> DISPLAYS = ConcurrentHashMap.newKeySet();

   private BanAnimation() {
   }

   public static boolean isActive(Player p) {
      return ACTIVE.contains(p.getUniqueId());
   }

   /** يُستدعى من onDisable */
   public static void cleanup() {
      for (Display d : DISPLAYS) {
         d.remove();
      }
      DISPLAYS.clear();
      ACTIVE.clear();
   }

   public static void play(ModerationPlugin plugin, Player target, CommandSender admin, Runnable onFinish) {
      FileConfiguration cfg = plugin.getConfig();
      if (!cfg.getBoolean("ban-animation.enabled", true)) {
         onFinish.run();
         return;
      }
      if (!ACTIVE.add(target.getUniqueId())) {
         return;
      }

      int headTicks = Math.max(10, cfg.getInt("ban-animation.head-ticks", 30));
      int titleTicks = Math.max(20, cfg.getInt("ban-animation.title-ticks", 70));
      double dist = cfg.getDouble("ban-animation.head-distance", 1.4);
      int step = Math.max(1, Math.min(5, cfg.getInt("ban-animation.update-every-ticks", 2)));
      boolean transparent = cfg.getBoolean("ban-animation.transparent-head", true);
      float endScale = transparent
         ? (float) cfg.getDouble("ban-animation.text-head-end-scale", 7.0)
         : (float) cfg.getDouble("ban-animation.head-end-scale", 2.4);

      String adminName = admin.getName();

      target.playSound(
         target.getLocation(),
         cfg.getString("ban-animation.sound", "entity.elder_guardian.curse"),
         SoundCategory.MASTER,
         (float) cfg.getDouble("ban-animation.sound-volume", 1.0),
         (float) cfg.getDouble("ban-animation.sound-pitch", 1.0)
      );

      Display display;
      if (transparent) {
         Component headComp = Component.object(buildHeadContents(cfg, admin));
         display = target.getWorld().spawn(front(target, dist), TextDisplay.class, e -> {
            e.setVisibleByDefault(false);
            e.setPersistent(false);
            e.text(headComp);
            e.setBillboard(Display.Billboard.CENTER);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setDefaultBackground(false);
            e.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            e.setShadowed(false);
            e.setSeeThrough(false);
            e.setTextOpacity((byte) 4);
            e.setTeleportDuration(step);
            e.setInterpolationDuration(step);
            e.setTransformation(pose(0.0, endScale, true));
         });
      } else {
         ItemStack skull = buildHead(cfg, admin);
         display = target.getWorld().spawn(front(target, dist), ItemDisplay.class, e -> {
            e.setVisibleByDefault(false);
            e.setPersistent(false);
            e.setItemStack(skull);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
            e.setBillboard(Display.Billboard.CENTER);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setTeleportDuration(step);
            e.setInterpolationDuration(step);
            e.setTransformation(pose(0.0, endScale, false));
         });
      }
      DISPLAYS.add(display);
      target.showEntity(plugin, display);

      new BukkitRunnable() {
         int tick = 0;

         @Override
         public void run() {
            if (!target.isOnline()) {
               display.remove();
               DISPLAYS.remove(display);
               ACTIVE.remove(target.getUniqueId());
               cancel();
               return;
            }

            if (tick < headTicks && tick % step == 0) {
               display.teleport(front(target, dist));
               double f = (double) tick / headTicks;
               display.setTransformation(pose(f, endScale, transparent));
               display.setInterpolationDelay(0);
               if (display instanceof TextDisplay td) {
                  double g = 0.05 + 0.5 * Math.sin(Math.PI * f);
                  td.setTextOpacity((byte) Math.max(4, Math.min(255, (int) (255 * g))));
               }
            }

            if (tick == headTicks) {
               display.remove();
               DISPLAYS.remove(display);

               String nameTpl = cfg.getString("ban-animation.title-name", "<red><bold><admin>");
               String subTpl = cfg.getString("ban-animation.title-sub", "<red><italic>Watching you, watch yourself");
               Component main = MM.deserialize(nameTpl.replace("<admin>", MM.escapeTags(adminName)));
               Component sub = MM.deserialize(subTpl);
               Title.Times times = Title.Times.times(
                  Duration.ofMillis(250), Duration.ofMillis(Math.max(500, (titleTicks - 10) * 50L)), Duration.ofMillis(250)
               );
               target.showTitle(Title.title(main, sub, times));
            }

            if (tick >= headTicks + titleTicks) {
               ACTIVE.remove(target.getUniqueId());
               cancel();
               onFinish.run();
               return;
            }
            tick++;
         }
      }.runTaskTimer(plugin, 0L, 1L);
   }

   private static Location front(Player p, double dist) {
      Location eye = p.getEyeLocation();
      return eye.clone().add(eye.getDirection().multiply(dist));
   }

   /** نفس منحنى تأثير Elder Guardian: g = 0.05 + 0.5*sin(pi*f)، الدوران = 150*g - 60 درجة، ينزل ويطلع مع الحجم */
   private static Transformation pose(double f, float endScale, boolean textMode) {
      double g = 0.05 + 0.5 * Math.sin(Math.PI * f);
      float k = (float) (g / 0.55);
      float s = Math.max(0.05f, endScale * k);
      float pitch = (float) Math.toRadians(150.0 * g - 60.0);
      return new Transformation(
         new Vector3f(0.0f, -0.6f * (1.0f - k) - (textMode ? 0.1f * s : 0.0f), 0.0f),
         new AxisAngle4f(pitch, 1.0f, 0.0f, 0.0f),
         new Vector3f(s, s, s),
         new AxisAngle4f()
      );
   }

   private static PlayerHeadObjectContents buildHeadContents(FileConfiguration cfg, CommandSender admin) {
      PlayerHeadObjectContents.Builder b = ObjectContents.playerHead().hat(true);
      if (admin instanceof Player p) {
         boolean has = false;
         for (ProfileProperty prop : p.getPlayerProfile().getProperties()) {
            if (prop.getName().equals("textures")) {
               b.profileProperty(PlayerHeadObjectContents.ProfileProperty.property("textures", prop.getValue()));
               has = true;
               break;
            }
         }
         if (!has) {
            b.id(p.getUniqueId()).name(p.getName());
         }
      } else {
         String owner = cfg.getString("ban-animation.console-head-owner", "Herobrine");
         String skin = cfg.getString("ban-animation.console-head-skin-url", "");
         if (skin != null && !skin.isBlank()) {
            String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + skin + "\"}}}";
            String b64 = Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
            b.profileProperty(PlayerHeadObjectContents.ProfileProperty.property("textures", b64));
         } else {
            b.name(owner);
         }
      }
      return b.build();
   }

   private static ItemStack buildHead(FileConfiguration cfg, CommandSender admin) {
      ItemStack item = new ItemStack(Material.PLAYER_HEAD);
      SkullMeta meta = (SkullMeta) item.getItemMeta();
      if (admin instanceof Player p) {
         meta.setOwningPlayer(p);
      } else {
         String owner = cfg.getString("ban-animation.console-head-owner", "Herobrine");
         String skin = cfg.getString("ban-animation.console-head-skin-url", "");
         PlayerProfile profile = null;
         if (skin != null && !skin.isBlank()) {
            try {
               profile = Bukkit.createPlayerProfile(UUID.randomUUID(), owner);
               profile.getTextures().setSkin(new URL(skin));
            } catch (Exception ex) {
               profile = null;
            }
         }
         if (profile == null) {
            profile = Bukkit.createPlayerProfile(owner);
         }
         meta.setOwnerProfile(profile);
      }
      item.setItemMeta(meta);
      return item;
   }
}
